#!/bin/sh
make -C /Users/elliotfiske/slumber/lab1/mac/built -f /Users/elliotfiske/slumber/lab1/mac/built/CMakeScripts/ALL_BUILD_cmakeRulesBuildPhase.make$CONFIGURATION all
