#!/bin/sh
make -C /Users/elliotfiske/slumber/lab1/mac/built -f /Users/elliotfiske/slumber/lab1/mac/built/CMakeScripts/ZERO_CHECK_cmakeRulesBuildPhase.make$CONFIGURATION all
