#include "camera.hpp"

Camera::Camera(vec3 center_, vec3 direction_, float velocityScale, float radius):
        Actor(center_, direction_, velocityScale, radius) {
   
}
