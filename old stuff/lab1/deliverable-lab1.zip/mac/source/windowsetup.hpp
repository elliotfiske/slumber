#include <stdio.h>
#include "GLSL.h"

GLFWwindow* setupWindow(); 
